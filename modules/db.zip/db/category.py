from . import pool

async def get_all_categories():
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM category ORDER BY category_id")
        return [dict(r) for r in rows]
