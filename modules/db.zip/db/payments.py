from . import pool

async def create_payment(order_id, mode, amount, tx_hash=None):
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO payment (order_id,payment_mode,amount,transaction_hash)
            VALUES ($1,$2,$3,$4)
        """, order_id, mode, amount, tx_hash)
